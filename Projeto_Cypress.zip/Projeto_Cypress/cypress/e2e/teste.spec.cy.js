describe('template spec', () => {
  beforeEach(() => {
    cy.visit('http://127.0.0.1:5500/login.html');
  });

  const login = (email, senha) => {
    cy.get('#email').clear().type(email);
    cy.get('#password').clear().type(senha);
    cy.get('.btn').click();
  };

  it('6 - Email em branco', () => {
    cy.get('#email').clear();
    cy.get('#password').clear().type('1@Bc');
    cy.get('.btn').click();
    cy.contains('Por favor, insira um e-mail válido.').should('exist');
  });

  it('8 - Email com dois "@"', () => {
    login('teste@@email.com', '1@Bc');
    cy.contains('Por favor, insira um e-mail válido.').should('exist');
  });

  it('10 - Espaços antes do domínio', () => {
    cy.get('#email').clear().invoke('val', 'tes te@email.com');
    cy.get('#password').clear().type('1@Bc');
    cy.get('.btn').click();
    cy.contains('Por favor, insira um e-mail válido.').should('exist');
  });

  it('12 - Espaços depois do domínio', () => {
    cy.get('#email').clear().invoke('val', 'teste@email. com');
    cy.get('#password').clear().type('1@Bc');
    cy.get('.btn').click();
    cy.contains('Por favor, insira um e-mail válido.').should('exist');
  });

  it('14 - Email com domínio incorreto', () => {
    login('teste@email', '1@Bc');
    cy.contains('Por favor, insira um e-mail válido.').should('exist');
  });

  it('16 - Senha em branco', () => {
    cy.get('#email').clear().type('teste@email.com');
    cy.get('#password').clear();
    cy.get('.btn').click();
    cy.contains('A senha deve ter entre 3 e 6 caracteres. A senha deve conter pelo menos um número. A senha deve conter pelo menos um caractere especial. A senha deve conter pelo menos uma letra maiúscula. A senha deve conter pelo menos uma letra minúscula').should('exist');
  });

  it('18 - Senha sem números', () => {
    login('teste@email.com', '@Bc');
    cy.contains('A senha deve conter pelo menos um número. ').should('exist');
  });

  it('20 - Senha sem caracteres especiais', () => {
    login('teste@email.com', '1Bc');
    cy.contains('A senha deve conter pelo menos um caractere especial. ').should('exist');
  });

  it('22 - Senha sem letras minúsculas', () => {
    login('teste@email.com', '1@BC');
    cy.contains('A senha deve conter pelo menos uma letra minúscula. ').should('exist');
  });

  it('24 - Senha sem letras maiúsculas', () => {
    login('teste@email.com', '1@bc');
    cy.contains('A senha deve conter pelo menos uma letra maiúscula. ').should('exist');
  });

  it('26 - Senha com menos de 3 dígitos', () => {
    login('teste@email.com', '1@');
    cy.contains('A senha deve ter entre 3 e 6 caracteres. ').should('exist');
  });

  it('28 - Senha com mais de 6 dígitos', () => {
    login('teste@email.com', '1@BcdEf');
    cy.contains('A senha deve ter entre 3 e 6 caracteres. ').should('exist');
  });

  it('30 - Email e senha incorretos', () => {
    cy.on('window:alert', (text) => {
      expect(text).to.contains('Credenciais inválidas.');
    });
  
    login('outro@email.com', 'Aa#2');
  });

  it('32 - Email e senha corretos', () => {
    login('teste@email.com', '1@Bc');
    cy.contains('LOGIN EFETUADO COM SUCESSO').should('exist');
  });
})