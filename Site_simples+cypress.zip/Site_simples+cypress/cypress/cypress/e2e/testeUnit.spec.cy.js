describe('template spec', () => {
  beforeEach(() => {
    cy.visit('http://127.0.0.1:5500/index.html');
  });
    const login = (email, senha) => {
    cy.get('#email').clear().type(email);
    cy.get('#email').should('have.value', email)
    cy.get('#enviar').click();
  };
  it('Campo em branco', () => {
    cy.get('#email').clear();
    cy.should('have.attr', 'placeholder', 'Digite seu email');
    cy.get('#enviar').click();
    cy.contains('Por favor, preencha o campo de email.').should('be.visible');
  })
  it('email preenchido incorretamente', () =>{
    cy.get('#email')
    cy.should('have.attr', 'placeholder', 'Digite seu email');
    login('testeteste.com');
    cy.contains('Email inválido. Tente novamente.').should('be.visible')
    cy.get('#email').clear().invoke('val', 'teste@em ail.com')
    cy.get('#email').should('have.value', 'teste@em ail.com')
    cy.get('#enviar').click();
    cy.contains('Email inválido. Tente novamente.').should('be.visible')
    login('teste@@teste.com')
    cy.contains('Email inválido. Tente novamente.').should('be.visible')
    login('te@ste@email.com')
    cy.contains('Email inválido. Tente novamente.').should('be.visible')
    login('teste@email,com')
    cy.contains('Email inválido. Tente novamente.').should('be.visible')
});
it('Email sem registro', () => {
  login('eu9.9@hotmail.com')
  cy.contains('Email não encontrado no registro. Acesso negado.').should('be.visible')
  login('admin@email.com.br')
  cy.contains('Email não encontrado no registro. Acesso negado.').should('be.visible')
  login('Email@email.com')
  cy.contains('Email não encontrado no registro. Acesso negado.').should('be.visible')
})
it('Dados corretos', () => {
  login('teste@teste.com.br')
  cy.contains('Email válido e encontrado em nosso registro!').should('be.visible')
  login('usuario@exemplo.com')
  cy.contains('Email válido e encontrado em nosso registro!').should('be.visible')
  login('admin@empresa.com')
  cy.contains('Email válido e encontrado em nosso registro!').should('be.visible')

})
;})